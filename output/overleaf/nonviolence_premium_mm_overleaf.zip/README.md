# The Nonviolence Premium (cross-national) — Overleaf package

**Authors.** Charles Crabtree (Monash University & Korea University) and
John B. Holbein (University of Virginia).

## Contents
- `paper.tex` — main manuscript
- `statistics.tex` — auto-generated macros consumed by `paper.tex`
  (produced by the project's R pipeline; included verbatim here)
- `references.bib` — APA-formatted bibliography
- `figures/*.pdf` — all figures referenced by `paper.tex`

## How to build on Overleaf
1. Upload the zip as a new project.
2. In Overleaf, open **Menu → Settings** and confirm:
   - Compiler: **pdfLaTeX**
   - Main document: **paper.tex**
3. Recompile. The document uses `apacite` for APA citations and
   `authblk` for multi-affiliation author blocks; both ship with
   Overleaf's default TeX Live, so no further setup is required.

## Notes
- The bibliography path has been flattened from `../references` (main
  repo layout) to `references` (Overleaf layout).
- `statistics.tex` is a snapshot of the macro file at the time the
  package was built; regenerating it requires the R pipeline in the
  project repository.
