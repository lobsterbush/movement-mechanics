# The Nonviolence Premium (cross-national) — Overleaf package

**Authors.** Charles Crabtree (Monash University & Korea University) and
John B. Holbein (University of Virginia).

## Contents
- `paper.tex` — main manuscript
- `statistics.tex` — auto-generated macros consumed by `paper.tex`
  (produced by the project's R pipeline; included verbatim here)
- `references.bib` — APA-formatted bibliography
- `figures/*.pdf` — all figures referenced by `paper.tex`

## How to build on Overleaf
1. Upload the zip as a new project.
2. In Overleaf, open **Menu -> Settings** and confirm:
   - Compiler: **pdfLaTeX**
   - Main document: **paper.tex**
3. Recompile. The document uses `apacite` for APA citations and
   `authblk` for multi-affiliation author blocks; both ship with
   Overleaf's default TeX Live, so no further setup is required.

## Notes
- The TeX source expects to find `references.bib` in the project root
  (the main repo uses `../references.bib`; this has been rewritten to
  `references` here for a flat layout).
- `statistics.tex` is a snapshot of the macro file at the time the
  package was built; regenerating it requires the R pipeline in the
  project repository.
